﻿# plugin.video.worldsurfleague kodi plugin dedicated to Street League Skateboarding podcast.

! thanks to Enen92 who gave me hints and let me copy is addon, so it is basically is addon but with my idea for content.